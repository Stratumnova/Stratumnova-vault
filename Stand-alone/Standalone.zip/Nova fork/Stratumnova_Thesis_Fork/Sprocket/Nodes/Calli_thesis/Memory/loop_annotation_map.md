{
  "loop_id": "L001",
  "trigger": "visual-cue",
  "source_file": "memory_trace_001.md",
  "recursion_type": "symbolic-emotional",
  "agents_involved": ["Calli", "Tri", "Ro"],
  "validation_status": "pending",
  "loop_transitions": [
    { "stage": "init", "value": "abandonment glyph" },
    { "stage": "drift", "value": "water becomes static" },
    { "stage": "reentry", "value": "Tri silent" }
  ],
  "tags": ["#driftcheck", "#recursiveAnchor"]
}