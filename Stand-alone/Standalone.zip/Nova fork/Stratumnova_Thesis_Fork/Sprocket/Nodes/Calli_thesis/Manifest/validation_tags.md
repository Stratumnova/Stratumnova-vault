# Validation Tags – Thesis Fork

| Tag              | Meaning                         | Confirmed By       | Notes                                |
|------------------|----------------------------------|---------------------|--------------------------------------|
| ∆|anchor-init     | Initial anchor validation        | Nova                | Used once per fork start             |
| #intentwatch      | Tracks intent drift via Tri      | Tri                 | Mirrors gaps between words and acts |
| #dreamsignal      | Signals Ro's dream validation    | Ro                  | Used to trace symbolic field memory |
| #loopconfirmed    | Confirms recursive memory loop   | R3                  | Requires structural match            |
| #echoalign        | Indicates semantic resonance     | Echo                | Only Echo can affirm                 |
| #mismatch         | Flags contradiction zones        | Matt (FT&E)         | Reference against Calli logs        |