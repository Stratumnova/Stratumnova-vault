[Placeholder] 99_Conclusion_Draft.md for Stratumnova Thesis Fork
